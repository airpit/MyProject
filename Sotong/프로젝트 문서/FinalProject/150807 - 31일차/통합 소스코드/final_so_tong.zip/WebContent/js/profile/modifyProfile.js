$(document).ready( function() {
	$("#modify-btn").click(function(){
		$("#family-modify-form").submit();
	});
});