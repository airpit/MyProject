package control.story;



import java.io.IOException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import manager.story.StoryManager;
import dao.home.FamilyMemberVO;
import dao.story.StoryViewVO;

/**
 * Servlet implementation class StoryServlet
 */
@WebServlet({ "/story.do", "/story-updateLoding.do", "/story-update.do", "/story-heart.do", "/story-write.do", "/story-delete.do" })
public class StoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String uri = request.getRequestURI();
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex+1);
		
		HttpSession session = request.getSession();
		FamilyMemberVO userInfo = (FamilyMemberVO)session.getAttribute("userInfo");
		
		StoryManager manager = new StoryManager();
		StoryViewVO[] storyList = manager.getStoryList(userInfo.getFamilyHomecode());
		
		request.setAttribute("storyList", storyList);
		RequestDispatcher rd = request.getRequestDispatcher("JSP/story/FamilyStory.jsp");
		rd.forward(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String uri = request.getRequestURI();
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex+1);
		String dispatchUrl = null;
		
		switch(action) {
			case "story-updateLoding.do" :
				
				break;
			case "story-update.do" :
							
				break;
			case "story-heart.do" :
				
				break;
			case "story-write.do" :
				requestAddStory(request, response);
				break;
			case "story-delete.do" :
				
				break;
				
		}
		
		doGet(request,response);
	}
	
	private void requestAddStory(HttpServletRequest request, HttpServletResponse response) {
		
		StoryManager manager = new StoryManager();
		
		HttpSession session = request.getSession();
		FamilyMemberVO userInfo = (FamilyMemberVO)session.getAttribute("userInfo");
		
		String storyContents = request.getParameter("family-board-content-write");
		String storyDate = newDate();
		String imageName = "img/nono";
		String emoticonCode = "em1";
		
		String scope = request.getParameter("public-scope");
		
		manager.addStory(userInfo.getFamilyHomecode(), userInfo.getMemberCode(),
				imageName, storyContents, emoticonCode, storyDate, scope);  
	}
	
	
	
	
	
	public String newDate() {
		
		Date dateTime = new Date();
		
		int year= dateTime.getYear() - 100;
		String mon = (dateTime.getMonth()+1)>9 ? "" + (dateTime.getMonth()+1) : "0" + (dateTime.getMonth()+1);
		String day = dateTime.getDate()>9 ? "" +dateTime.getDate() : "0" + dateTime.getDate();
	    String hour = dateTime.getHours()>9 ? "" + dateTime.getHours() : "0" + dateTime.getHours(); 
	    String min = dateTime.getMinutes()>9 ? "" + dateTime.getMinutes() : "0" + dateTime.getMinutes();
	   
		return  year + "-" + mon +"-" + day + "-" + hour + ":" + min; 
	}

}
