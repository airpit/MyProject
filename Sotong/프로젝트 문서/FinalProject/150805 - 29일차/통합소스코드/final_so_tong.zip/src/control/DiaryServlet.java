package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import manager.DiaryManager;
import dao.diary.DiaryViewVO;
import dao.home.FamilyMemberVO;

/**
 * Servlet implementation class Diary
 */
@WebServlet(urlPatterns={"/diary.do" , "/diaryList.do" , "/diary_insert.do" ,"/diary_update.do", "/diary_modify.do", "/diary_delete.do"})
public class DiaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet() 
     */
    public DiaryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }                                                                                     

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String uri = request.getRequestURI();
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex+1);
		
		
		requestGetSimpleList(request,response);
		
	
		
		if(action.equals("diaryList.do"))		// �������� ��ϸ� �ʿ��� ���.
		{
			RequestDispatcher rd = request.getRequestDispatcher("JSP/diary/MyDiaryWrite.jsp");
			rd.forward(request, response);
		}
		else if(action.equals("diary_modify.do"))	// ������ ������ ���.
		{
			//������ �ϱ⿡ ���� ������ �о���� �κ��� �־�߰ڴ�.
			//�׳� �����̰ų� ������ ��쿡�� �о���ڳ�
			String diaryCode = request.getParameter("diaryCode");
			
			DiaryManager manager = new DiaryManager();
			
			DiaryViewVO diaryInfo = manager.getIndividualDiaryInfo(diaryCode);
			
			request.setAttribute("diaryInfo", diaryInfo);
			
			RequestDispatcher rd = request.getRequestDispatcher("JSP/diary/MyDiaryModify.jsp");
			rd.forward(request, response);
		}
		else
		{			
			RequestDispatcher rd = request.getRequestDispatcher("JSP/diary/MyDiary.jsp");
			rd.forward(request, response);	
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String uri = request.getRequestURI();
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex+1);
		
		if(action.equals("diary_insert.do"))
		{
			requestAddDiary(request,response);
		}
		else if(action.equals("diary_update.do"))
		{
			requestUpdateDiary(request,response);
		}
		else if(action.equals("diary_delete.do"))	// ������ ������ ���.
		{
			System.out.println("���Ͷ� : " + request.getAttribute("diaryCode"));
			
			requestDeleteDiary(request,response);
		}
		
		doGet(request,response);

	}
	
	//���� ������ �ҷ����� �޼ҵ�.
	private void requestGetSimpleList(HttpServletRequest request, HttpServletResponse response)
	{
		DiaryViewVO diaryInfo = null;
		
		DiaryManager manager = new DiaryManager();
		
		HttpSession session = request.getSession();
		
		FamilyMemberVO userInfo = (FamilyMemberVO)session.getAttribute("userInfo");
		String[][] simpleDiaryList = manager.getSimpleIndividualDiaryList(userInfo.getMemberCode());
		//�ش� ������ ���� �ڵ�� �����ϱⰣ���������� �ҷ��´�.
		
		request.setAttribute("simpleDiaryList", simpleDiaryList);		
		
		if(simpleDiaryList != null)
		{
			String diaryCode = request.getParameter("diaryCode");
			
			
			/*
			if(diaryCode != null && diaryCode.equals(request.getAttribute("diaryCode")))
			{
				diaryCode = "";
			}
			*/
			
			if(diaryCode == null/* || diaryCode.equals("")*/)//��üũ �Ӹ� �ƴ϶� ���鹮�� üũ�� �ؾ���!! �߰��ض� ��
			{
				diaryInfo = manager.getIndividualDiaryInfo(simpleDiaryList[0][0]);
			}
			else
			{
				diaryInfo = manager.getIndividualDiaryInfo(diaryCode);
			}
			

			request.setAttribute("diaryInfo", diaryInfo);
		}
	}
	
	//�����ϱ⸦ �߰��ϴ� �޼ҵ�.
	private void requestAddDiary(HttpServletRequest request, HttpServletResponse response)
	{
		DiaryManager manager = new DiaryManager();
		
		HttpSession session = request.getSession();
		FamilyMemberVO userInfo = (FamilyMemberVO)session.getAttribute("userInfo");
		
		String diaryTitle = request.getParameter("diaryTitle");
		String contents = request.getParameter("diaryContents");
		String diaryDate = "15-08-05";
		String imageName = "img/nono";		// image�� �̸�Ƽ���� ���� ����.
		String imageWrittenDate = diaryDate;
		String emoticonCode = "em1";

		manager.addIndividualDiary(userInfo.getMemberCode(), userInfo.getFamilyHomecode(), diaryTitle, diaryDate, contents, imageName, imageWrittenDate, emoticonCode);
	}
	
	private void requestUpdateDiary(HttpServletRequest request, HttpServletResponse response)
	{
		DiaryManager manager = new DiaryManager();
		
		HttpSession session = request.getSession();
		FamilyMemberVO userInfo = (FamilyMemberVO)session.getAttribute("userInfo");
		
		String diaryCode = request.getParameter("diaryCode");
		String diaryTitle = request.getParameter("diaryTitle");
		String contents = request.getParameter("contents");
		String diaryDate = request.getParameter("diaryDate");
		String sotongContentsCode = request.getParameter("sotongContentsCode");
		String imageName = "img/testData";
		String imageWrittenDate = diaryDate;
		String emoticonCode = "em1";

		manager.updateIndividualDiary(diaryCode, userInfo.getMemberCode(), sotongContentsCode, diaryTitle, diaryDate, contents, imageName, imageWrittenDate, emoticonCode);
	
	}
	
	private void requestDeleteDiary(HttpServletRequest request, HttpServletResponse response)
	{
		DiaryManager manager = new DiaryManager();
		
		String diaryCode = request.getParameter("diaryCode");
		String sotongContentsCode = request.getParameter("sotongContentsCode");
		
		manager.deleteIndividualDiary(diaryCode,sotongContentsCode);			
	}
}
