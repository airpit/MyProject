package manager;

import dao.diary.FamilyDiaryDAO;
import dao.diary.FamilyDiaryPartDAO;
import dao.diary.FamilyDiaryVO;
import dao.diary.FamilyDiaryViewDAO;
import dao.diary.FamilyDiaryViewVO;

public class FamilyDiaryManager 
{
	private FamilyDiaryViewDAO familyDiaryViewDAO;
	private FamilyDiaryDAO familyDiaryDAO;
	private FamilyDiaryPartDAO familyDiaryPartDAO;
	
	public FamilyDiaryManager() {
		familyDiaryViewDAO = new FamilyDiaryViewDAO();
		familyDiaryDAO = new FamilyDiaryDAO();
		familyDiaryPartDAO = new FamilyDiaryPartDAO();
	}
	
	public FamilyDiaryVO[] getSimpleFamilyDiaryList(String homeCode)
	{
		return familyDiaryDAO.selectAllDiaryInfo(homeCode);
	}
	
	public FamilyDiaryViewVO[] getFamilyDiaryInfo(String familyDiaryCode)
	{
		return familyDiaryViewDAO.selectDiaryInfo(familyDiaryCode);
	}

}
