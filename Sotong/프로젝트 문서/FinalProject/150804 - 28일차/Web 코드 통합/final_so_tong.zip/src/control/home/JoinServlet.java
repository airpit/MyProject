package control.home;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import manager.home.JoinManager;

/**
 * Servlet implementation class JoinServlet
 */
@WebServlet("/join.do")
public class JoinServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("Join-Get-Method");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		PrintWriter out = response.getWriter();
		RequestDispatcher rd = null;
		
		String joinServiceRoute = request.getParameter("joinServiceRoute");
		String joinId = request.getParameter("joinId");
		String joinPassword = request.getParameter("joinPassword");
		String joinName = request.getParameter("joinName");
		String joinEmail = request.getParameter("joinEmail");
		String joinHomeCode = request.getParameter("joinHomeCode");
		String joinPhoneNum = request.getParameter("joinPhoneNum");
		
		System.out.println("ȸ�� ���� ����");
		System.out.println("id : " + joinId);
		System.out.println("pw : " + joinPassword);
		System.out.println("name : " + joinName);
		System.out.println("email : " + joinEmail);
		System.out.println("homeCode : " + joinHomeCode);
		System.out.println("phone : " + joinPhoneNum);
		
		
		JoinManager joinManager = new JoinManager();
		
		int checkJoin = 0;
		byte checkId = joinManager.checkId(joinId);
		
		System.out.println(checkId);
		
		if (checkId == -1) {
			//���̵� ���� ���� 
			
			if (joinHomeCode != null) {
				// �ʴ� �޾� ���� �ϴ� ���
				checkJoin = joinManager.joinMember(joinId, joinPassword, joinName, joinEmail, joinPhoneNum, joinHomeCode);
			} else {
				// �ʴ� ���� �ʰ� ���� ���� ���
				checkJoin = joinManager.joinMember(joinId, joinPassword, joinName, joinEmail, joinPhoneNum, joinHomeCode);
			}
			
			if (joinServiceRoute.equals("2000")) {
				// web���� ȸ�� ���� �ϴ� ���
			
				if (checkJoin != 0) {
					rd = request.getRequestDispatcher("main.html");
				} else {
					rd = request.getRequestDispatcher("main.html");	
				}
			} else {
				// App���� ȸ�� �����ϴ� ���
				System.out.println("App ���Գ�?");
				System.out.println(checkJoin);
				
				if (checkJoin != 0) {
					System.out.println("����");
					out.println("success");
				} else {
					System.out.println("����");
					out.println("fail");
				}
			}
		} else {
			//���̵� �̹� �ִ� ���
			if (joinServiceRoute.equals("2000")) {
				// web���� ȸ�� ���� �ϴ� ���
				out.println("alert('User or password incorrect');");
			    out.println("location='index.jsp';");
				rd = request.getRequestDispatcher("main.html");
			} else {
				// App���� ȸ�� �����ϴ� ���
				System.out.println("App ���Գ�?");
				System.out.println("����");
				out.println("fail");
			}
			
		}
		
	}

}
