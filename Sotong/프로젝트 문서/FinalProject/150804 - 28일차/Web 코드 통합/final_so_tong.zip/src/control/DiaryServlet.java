package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import manager.DiaryManager;
import dao.diary.DiaryViewVO;
import dao.home.FamilyMemberVO;

/**
 * Servlet implementation class Diary
 */
@WebServlet(urlPatterns={"/diary.do" , "/diaryList.do" , "/diary_insert.do" , "/diary_update.do", "/diary_delete.do"})
public class DiaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet() 
     */
    public DiaryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String uri = request.getRequestURI();
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex+1);
		
		DiaryManager manager = new DiaryManager();
		
		HttpSession session = request.getSession();
		
		FamilyMemberVO userInfo = (FamilyMemberVO)session.getAttribute("userInfo");
		String[][] simpleDiaryList = manager.getSimpleIndividualDiaryList(userInfo.getMemberCode());
				
		request.setAttribute("simpleDiaryList", simpleDiaryList);		
		
		if(action.equals("diaryList.do"))
		{
			RequestDispatcher rd = request.getRequestDispatcher("JSP/diary/MyDiaryWrite.jsp");
			rd.forward(request, response);
		}
		else
		{
			if(simpleDiaryList != null)
			{
				DiaryViewVO diaryInfo = manager.getIndividualDiaryInfo(simpleDiaryList[0][0]);
				
				request.setAttribute("diaryInfo", diaryInfo);
			}
			
			RequestDispatcher rd = request.getRequestDispatcher("JSP/diary/MyDiary.jsp");
			rd.forward(request, response);	
		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String uri = request.getRequestURI();
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex+1);
		String dispatchUrl = null;
		
		if(action.equals("diary_insert.do"))
		{
			requestAddDiary(request,response);
		}
		else if(action.equals("diary_update.do"))
		{
			requestUpdateDiary(request,response);
		}
		else if(action.equals("diary_delete.do"))
		{
			requestDeleteDiary(request,response);
		}
		
		doGet(request,response);

	}
	
	private void requestAddDiary(HttpServletRequest request, HttpServletResponse response)
	{
		DiaryManager manager = new DiaryManager();
		
		HttpSession session = request.getSession();
		FamilyMemberVO userInfo = (FamilyMemberVO)session.getAttribute("userInfo");
		
		String diaryTitle = request.getParameter("diaryTitle");
		String contents = request.getParameter("diaryContents");
		String diaryDate = "15-08-04";
		String imageName = "img/nono";
		String imageWrittenDate = "15-08-04";
		String emoticonCode = "nonono";
		
		System.out.println(diaryTitle);
		System.out.println(contents);
		
		manager.addIndividualDiary(userInfo.getMemberCode(), userInfo.getFamilyHomecode(), diaryTitle, diaryDate, contents, imageName, imageWrittenDate, emoticonCode);
	}
	
	private void requestUpdateDiary(HttpServletRequest request, HttpServletResponse response)
	{
		DiaryManager manager = new DiaryManager();
		
		DiaryViewVO diaryInfo = (DiaryViewVO)request.getAttribute("diaryInfo");
		
		String familyHomeCode = ((FamilyMemberVO)request.getAttribute("member")).getFamilyHomecode();
		String memberCode = ((FamilyMemberVO)request.getAttribute("member")).getMemberCode();
		
		
	//	manager.addIndividualDiary(familyHomeCode,memberCode,diaryInfo.getDiaryTitle(),diaryInfo.getDiaryDate(),diaryInfo.getContents(),diaryInfo.getImageName(),diaryInfo.getImageWrittenDate(),diaryInfo.gete1m)
		
	}
	
	private void requestDeleteDiary(HttpServletRequest request, HttpServletResponse response)
	{
		DiaryManager manager = new DiaryManager();
		
		DiaryViewVO diaryInfo = (DiaryViewVO)request.getAttribute("diaryInfo");
		
		manager.deleteIndividualDiary(diaryInfo.getDiaryCode(), diaryInfo.getSotongContentsCode());		
	}
}
