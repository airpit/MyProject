package manager;

import dao.sotong.EmoticonDAO;
import dao.sotong.ImageDAO;

public class SotongManager {
	private ImageDAO imageDAO;
	private EmoticonDAO emoticonDAO;
	
	public SotongManager()
	{
		imageDAO=new ImageDAO();
		emoticonDAO=new EmoticonDAO();
	}
	
	public String addSotongContents(String familyHomeCode, String sotongCategoryCode, String contents, String imageName, String imageWrittenDate, String emoticonCode)
	{
		return "h4";
	}
	

	
}
