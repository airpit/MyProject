package normal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class LetterInfoDAO {
private DBConnectionModule connModule;
private Connection conn;

public LetterInfoDAO()
{
	connModule=DBConnectionModule.getInstance();
	conn=connModule.getConn();
}

public int insert(String sotongContentsCode,String senderCode,String receiverCode,String letterTitle,Date sendDate)
{
	int rowNum=0;
	Date date=null;
	PreparedStatement pstmt=null;
	try
	{date=new Date();
		String sql="insert into letter_tb values(?,?,?,?,?,?)";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, ""+(date.getYear()+1900)+date.getMonth()+date.getDate()+date.getHours()+date.getMinutes()+date.getSeconds());
		pstmt.setString(2,sotongContentsCode);
		pstmt.setString(3,senderCode);
		pstmt.setString(4,receiverCode);
		pstmt.setString(5,letterTitle);
		String date2;
		if(sendDate.getDate()>=9)
		{
			if(sendDate.getMonth()>=9)
			{
			date2=""+(sendDate.getYear()+1900)+"-"+(sendDate.getMonth()+1)+"-"+(sendDate.getDate()+1);
			}
			else
			{
			date2=""+(sendDate.getYear()+1900)+"-0"+(sendDate.getMonth()+1)+"-"+(sendDate.getDate()+1);
			}
		}
		else
		{
			if(sendDate.getMonth()>=9)
			{
			date2=""+(sendDate.getYear()+1900)+"-"+(sendDate.getMonth()+1)+"-0"+(sendDate.getDate()+1);
			}
			else
			{
			date2=""+(sendDate.getYear()+1900)+"-0"+(sendDate.getMonth()+1)+"-0"+(sendDate.getDate()+1);
			}
		}
		pstmt.setString(6,date2);
		rowNum=pstmt.executeUpdate();
	}
	catch(SQLException se)
	{
		//se.printStackTrace();
	}
	catch(Exception e)
	{
		//e.printStackTrace();
	}
	finally
	{
		try
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
		}
		catch(SQLException se)
		{
			//se.printStackTrace();
		}
	}
	
	return rowNum;
			
}
public int delete(String letterCode)
{
	int rowNum=0;
	
	PreparedStatement pstmt=null;
	try
	{
		String sql="Delete FROM letter_tb WHERE letter_code=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, letterCode);
		rowNum=pstmt.executeUpdate();
	}
	catch(SQLException se)
	{
		//se.printStackTrace();
	}
	catch(Exception e)
	{
		//e.printStackTrace();
	}
	finally
	{
		try
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
		}
		catch(SQLException se)
		{
			//se.printStackTrace();
		}
	}
	
	return rowNum;
			
}
public int update(String letterCode,LetterInfoVO infoVo)
{
	int rowNum=0;
	
	PreparedStatement pstmt=null;
	try
	{
		
		String sql="UPDATE letter_tb SET sotong_contents_code=?,sender_code=?,receiver_code=?,letter_title=?,send_date=? WHERE letter_code=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, infoVo.getSotongContentsCode());
		pstmt.setString(2, infoVo.getSenderCode());
		pstmt.setString(3, infoVo.getReceiverCode());
		pstmt.setString(4, infoVo.getLetterTitle());
		String date2;
		if(infoVo.getSendDate().getDate()>=9)
		{
			if(infoVo.getSendDate().getMonth()>=9)
			{
			date2=""+(infoVo.getSendDate().getYear())+"-"+(infoVo.getSendDate().getMonth())+"-"+(infoVo.getSendDate().getDate());
			}
			else
			{
			date2=""+(infoVo.getSendDate().getYear())+"-0"+(infoVo.getSendDate().getMonth())+"-"+(infoVo.getSendDate().getDate());
			}
		}
		else
		{
			if(infoVo.getSendDate().getMonth()>=9)
			{
			date2=""+(infoVo.getSendDate().getYear())+"-"+(infoVo.getSendDate().getMonth())+"-0"+(infoVo.getSendDate().getDate());
			}
			else
			{
			date2=""+(infoVo.getSendDate().getYear())+"-0"+(infoVo.getSendDate().getMonth())+"-0"+(infoVo.getSendDate().getDate());
			}
		}
		pstmt.setString(5, date2);
		pstmt.setString(6, letterCode);
		rowNum=pstmt.executeUpdate();
	}
	catch(SQLException se)
	{
		//se.printStackTrace();
	}
	catch(Exception e)
	{
		//e.printStackTrace();
	}
	finally
	{
		try
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
		}
		catch(SQLException se)
		{
			//se.printStackTrace();
		}
	}
	
	return rowNum;
			
}
public LetterInfoVO select(String letterCode)
{
	int rowNum=0;
	
	PreparedStatement pstmt=null;
	LetterInfoVO infoVo=null;
	try
	{
		
		String sql="SELECT * FROM letter_tb where LETTER_CODE=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, letterCode);
		ResultSet rs=pstmt.executeQuery();
		rs.next();
		infoVo=new LetterInfoVO();
		infoVo.setSotongContentsCode(rs.getString("sotong_contents_code"));
		infoVo.setSenderCode(rs.getString("sender_code"));
		infoVo.setReceiverCode(rs.getString("receiver_code"));
		infoVo.setLetterTitle(rs.getString("letter_title"));
		String date=rs.getString("send_date");
		String year=date.substring(0,4);
		
		String month=date.substring(5,7);
		String day=date.substring(8,10);
		System.out.println(year+"/"+month+"/"+day);
		Date date2=new Date(Integer.parseInt(year.trim()),Integer.parseInt(month.trim()),Integer.parseInt(day.trim()));
		infoVo.setSendDate(date2);
		System.out.println(new Date().getDate());
		
		rowNum=pstmt.executeUpdate();
	}
	catch(SQLException se)
	{
		//se.printStackTrace();
	}
	catch(Exception e)
	{
		//e.printStackTrace();
	}
	finally
	{
		try
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
		}
		catch(SQLException se)
		{
			//se.printStackTrace();
		}
	}
	
	return infoVo;
			
}

public static void main(String args[])
{
	LetterInfoDAO dao=new LetterInfoDAO();
	//dao.delete("201563202230");
	dao.insert("scontents2", "m4", "m1", "��wq��w��w��", new Date());
	dao.update("201563203644", dao.select("l1"));
	//System.out.println(dao.select("201563203644"));
}
}
