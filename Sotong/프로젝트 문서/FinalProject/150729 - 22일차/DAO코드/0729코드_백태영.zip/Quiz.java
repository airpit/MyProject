package com.lec.model;

public class Quiz {
	private String quizContents;
	private String quizResponse;
	private String receiver;
	private String sender;
	public Quiz()
	{	
	}
	public Quiz(String quizContents, String quizResponse, String receiver,
			String sender) {
		super();
		this.quizContents = quizContents;
		this.quizResponse = quizResponse;
		this.receiver = receiver;
		this.sender = sender;
	}
	public String getQuizContents() {
		return quizContents;
	}
	public void setQuizContents(String quizContents) {
		this.quizContents = quizContents;
	}
	public String getQuizResponse() {
		return quizResponse;
	}
	public void setQuizResponse(String quizResponse) {
		this.quizResponse = quizResponse;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	
}
