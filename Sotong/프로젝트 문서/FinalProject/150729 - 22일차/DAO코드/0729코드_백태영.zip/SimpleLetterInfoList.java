package com.lec.model;

import java.util.List;

public class SimpleLetterInfoList {
	private List<SimpleLetterInfo> simpleInfoList;

	public SimpleLetterInfoList(List<SimpleLetterInfo> simpleInfoList) {
		super();
		this.simpleInfoList = simpleInfoList;
	}
	

	public List<SimpleLetterInfo> getSimpleInfoList() {
		return simpleInfoList;
	}


	public void setSimpleInfoList(List<SimpleLetterInfo> simpleInfoList) {
		this.simpleInfoList = simpleInfoList;
	}


	@Override
	public String toString() {
		return "SimpleLetterInfoList [simpleInfoList=" + simpleInfoList + "]";
	}
	
}
