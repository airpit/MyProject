package com.lec.model;

public class LetterInfo {
	private SimpleLetterInfo simpleLetter;
	private SotongContentsInfo sotongContents;
	private String receiver;
	
	public LetterInfo()
	{}
	public LetterInfo(SimpleLetterInfo simpleLetter,
			SotongContentsInfo sotongContents, String receiver) {
		super();
		this.simpleLetter = simpleLetter;
		this.sotongContents = sotongContents;
		this.receiver = receiver;
	}
	public SimpleLetterInfo getSimpleLetter() {
		return simpleLetter;
	}
	public void setSimpleLetter(SimpleLetterInfo simpleLetter) {
		this.simpleLetter = simpleLetter;
	}
	public SotongContentsInfo getSotongContents() {
		return sotongContents;
	}
	public void setSotongContents(SotongContentsInfo sotongContents) {
		this.sotongContents = sotongContents;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	@Override
	public String toString() {
		return "LetterInfo [simpleLetter=" + simpleLetter + ", sotongContents="
				+ sotongContents + ", receiver=" + receiver + "]";
	}
	
}
