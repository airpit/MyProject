package com.lec.model;

public class SimpleLetterInfo {
	private String letterCode;
	private String letterTitle;
	private String senderName;
	private String sendDate;
	
	
	public SimpleLetterInfo()
	{}
	public SimpleLetterInfo(String letterCode, String letterTitle,
			String senderName, String sendDate) {
		super();
		this.letterCode = letterCode;
		this.letterTitle = letterTitle;
		this.senderName = senderName;
		this.sendDate = sendDate;
	}
	public String getLetterCode() {
		return letterCode;
	}
	public void setLetterCode(String letterCode) {
		this.letterCode = letterCode;
	}
	public String getLetterTitle() {
		return letterTitle;
	}
	public void setLetterTitle(String letterTitle) {
		this.letterTitle = letterTitle;
	}
	public String getSenderName() {
		return senderName;
	}
	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}
	public String getSendDate() {
		return sendDate;
	}
	public void setSendDate(String sendDate) {
		this.sendDate = sendDate;
	}
	@Override
	public String toString() {
		return "SimpleLetterInfo [letterCode=" + letterCode + ", letterTitle="
				+ letterTitle + ", senderName=" + senderName + ", sendDate="
				+ sendDate + "]";
	}
	

}
