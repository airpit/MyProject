package com.lec.model;

import java.util.List;

public class LetterInfoList {
	private List<LetterInfo> letters;

	public LetterInfoList()
	{}
	public LetterInfoList(List<LetterInfo> letters) {
		super();
		this.letters = letters;
	}

	public List<LetterInfo> getLetters() {
		return letters;
	}

	public void setLetters(List<LetterInfo> letters) {
		this.letters = letters;
	}
	@Override
	public String toString() {
		return "LetterInfoList [letters=" + letters + "]";
	}
	
}
