package com.lec.model;

public class LetterBox {
	private LetterInfoList list;
	public LetterBox()
	{}
	public LetterBox(LetterInfoList list) {
		super();
		this.list = list;
	}

	public LetterInfoList getList() {
		return list;
	}

	public void setList(LetterInfoList list) {
		this.list = list;
	}

	@Override
	public String toString() {
		return "LetterBox [list=" + list + "]";
	}
	
}
