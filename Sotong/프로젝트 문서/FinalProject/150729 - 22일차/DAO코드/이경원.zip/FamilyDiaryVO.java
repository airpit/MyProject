package dao;

import java.util.Date;

public class FamilyDiaryVO {
	private String familyDiaryCode;
	private String familyHomeCode;
	private String familyDiaryPartCode;
	private Date familyDiaryDate;
	
	public FamilyDiaryVO() {
		// TODO Auto-generated constructor stub
	}

	public FamilyDiaryVO(String familyDiaryCode, String familyHomeCode,
			String familyDiaryPartCode, Date familyDiaryDate) {
		super();
		this.familyDiaryCode = familyDiaryCode;
		this.familyHomeCode = familyHomeCode;
		this.familyDiaryPartCode = familyDiaryPartCode;
		this.familyDiaryDate = familyDiaryDate;
	}

	public String getFamilyDiaryCode() {
		return familyDiaryCode;
	}

	public void setFamilyDiaryCode(String familyDiaryCode) {
		this.familyDiaryCode = familyDiaryCode;
	}

	public String getFamilyHomeCode() {
		return familyHomeCode;
	}

	public void setFamilyHomeCode(String familyHomeCode) {
		this.familyHomeCode = familyHomeCode;
	}

	public String getFamilyDiaryPartCode() {
		return familyDiaryPartCode;
	}

	public void setFamilyDiaryPartCode(String familyDiaryPartCode) {
		this.familyDiaryPartCode = familyDiaryPartCode;
	}

	public Date getFamilyDiaryDate() {
		return familyDiaryDate;
	}

	public void setFamilyDiaryDate(Date familyDiaryDate) {
		this.familyDiaryDate = familyDiaryDate;
	}

	@Override
	public String toString() {
		return "FamilyDiaryVO [familyDiaryCode=" + familyDiaryCode
				+ ", familyHomeCode=" + familyHomeCode
				+ ", familyDiaryPartCode=" + familyDiaryPartCode
				+ ", familyDiaryDate=" + familyDiaryDate + "]";
	}
}
