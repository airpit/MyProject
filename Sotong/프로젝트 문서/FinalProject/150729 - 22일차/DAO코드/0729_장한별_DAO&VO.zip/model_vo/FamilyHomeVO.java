package model_vo;

public class FamilyHomeVO {
	private String familyHomeCode;
	private String familyHomeName;
	
	public FamilyHomeVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FamilyHomeVO(String familyHomeCode, String familyHomeName) {
		super();
		this.familyHomeCode = familyHomeCode;
		this.familyHomeName = familyHomeName;
	}
	public String getFamilyHomeCode() {
		return familyHomeCode;
	}
	public void setFamilyHomeCode(String familyHomeCode) {
		this.familyHomeCode = familyHomeCode;
	}
	public String getFamilyHomeName() {
		return familyHomeName;
	}
	public void setFamilyHomeName(String familyHomeName) {
		this.familyHomeName = familyHomeName;
	}

	public String toString() {
		return "FamilyHomeVO [familyHomeCode=" + familyHomeCode
				+ ", familyHomeName=" + familyHomeName + "]";
	}
	
	
}
