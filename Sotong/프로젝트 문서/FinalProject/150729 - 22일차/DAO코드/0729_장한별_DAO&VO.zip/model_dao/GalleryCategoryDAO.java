package model_dao;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

public class GalleryCategoryDAO {
	private DBConnectionModule connModule;
	private Connection conn;
	
	public GalleryCategoryDAO() {
		connModule = DBConnectionModule.getInstance();
		conn = connModule.getConn();
	}
	
	public String galleryCode(){ //�ӽ��ڵ�
		Date d = new Date();
		StringTokenizer st = new StringTokenizer(new SimpleDateFormat().format(d),". ");
			
		String year = st.nextToken();
		String month = st.nextToken();
		String day = st.nextToken();
			
		String galleryCode = "4000"+day+year+month+d.getHours()+d.getMinutes()+d.getSeconds();
		return galleryCode;
	}
	
}
