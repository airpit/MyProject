package model_dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;

import model_vo.FamilyMemberVO;


public class FamilyMemberDAO {
	private DBConnectionModule connModule;
	private Connection conn;
	
	public FamilyMemberDAO() {
		connModule = DBConnectionModule.getInstance();
		conn = connModule.getConn();
	}
	
	public String makeMemberCode(){ //�ӽ��ڵ�
		Date d = new Date();
		StringTokenizer st = new StringTokenizer(new SimpleDateFormat().format(d),". ");
			
		String year = st.nextToken();
		String month = st.nextToken();
		String day = st.nextToken();
			
		String memberCode = "3000"+day+year+month+d.getHours()+d.getMinutes()+d.getSeconds();
		return memberCode;
	}
	
	public int insertMember(String familyHomecode, 
			String memberName, String memberPhone, String memberEmail,
			String memberId, String memberPw, String memberPhoto,
			String memberNickName, String memberColor, Date memberBirth,
			byte memberRole)
	{
		int rowNum = 0;
		PreparedStatement pstmt = null;
		try{
			String sql = "insert into family_member_tb values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, makeMemberCode());
			pstmt.setString(2, familyHomecode);
			pstmt.setString(3, memberName);
			pstmt.setString(4, memberPhone);
			pstmt.setString(5, memberEmail);
			pstmt.setString(6, memberId);
			pstmt.setString(7, memberPw);
			pstmt.setString(8, memberPhoto);
			pstmt.setString(9, memberNickName);
			pstmt.setString(10, memberColor);
			pstmt.setString(11, format(memberBirth));
			pstmt.setByte(12, memberRole);
					
			rowNum = pstmt.executeUpdate();
			if(rowNum != 0)
			{
				conn.commit();
			}
			else
			{
				conn.rollback();
			}
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return rowNum;
	}
	
	public int updateMember(String memberCode, String familyHomecode, 
			String memberName, String memberPhone, String memberEmail,
			String memberId, String memberPw, String memberPhoto,
			String memberNickName, String memberColor, Date memberBirth,
			byte memberRole)
	{
		int rowNum = 0;
		PreparedStatement pstmt = null;
		try{
			String sql = "update family_member_tb set family_home_code = ?, member_name=?, member_phone=?, member_email=?, member_id=?, member_pw=?, member_photo=?, member_nickname=?, member_color=?, member_birth=?, member_role=? where member_code = ?";
			pstmt = conn.prepareStatement(sql);
			
			
			pstmt.setString(1, familyHomecode);
			pstmt.setString(2, memberName);
			pstmt.setString(3, memberPhone);
			pstmt.setString(4, memberEmail);
			pstmt.setString(5, memberId);
			pstmt.setString(6, memberPw);
			pstmt.setString(7, memberPhoto);
			pstmt.setString(8, memberNickName);
			pstmt.setString(9, memberColor);
			pstmt.setString(10, format(memberBirth));
			pstmt.setByte(11, memberRole);
			
			pstmt.setString(12, memberCode);
					
			rowNum = pstmt.executeUpdate();
			if(rowNum != 0)
			{
				conn.commit();
			}
			else
			{
				conn.rollback();
			}
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return rowNum;
	}
	
	public int updateMemberById(String familyHomecode, 
			String memberName, String memberPhone, String memberEmail,
			String memberId, String memberPw, String memberPhoto,
			String memberNickName, String memberColor, Date memberBirth,
			byte memberRole)
	{
		int rowNum = 0;
		PreparedStatement pstmt = null;
		try{
			String sql = "update family_member_tb set family_home_code = ?, member_name=?, member_phone=?, member_email=?, member_id=?, member_pw=?, member_photo=?, member_nickname=?, member_color=?, member_birth=?, member_role=? where member_id = ?";
			pstmt = conn.prepareStatement(sql);
			
			
			pstmt.setString(1, familyHomecode);
			pstmt.setString(2, memberName);
			pstmt.setString(3, memberPhone);
			pstmt.setString(4, memberEmail);
			pstmt.setString(5, memberId);
			pstmt.setString(6, memberPw);
			pstmt.setString(7, memberPhoto);
			pstmt.setString(8, memberNickName);
			pstmt.setString(9, memberColor);
			pstmt.setString(10, format(memberBirth));
			pstmt.setByte(11, memberRole);
			
			pstmt.setString(12, memberId);
					
			rowNum = pstmt.executeUpdate();
			if(rowNum != 0)
			{
				conn.commit();
			}
			else
			{
				conn.rollback();
			}
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return rowNum;
	}
	
	public int deleteMember(String memberCode)
	{
		int rowNum=0;
		PreparedStatement pstmt = null;
		try{
			String sql = "delete from family_member_tb where member_code=?";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, memberCode);
			rowNum = pstmt.executeUpdate();
			if(rowNum != 0)
			{
				conn.commit();
			}
			else
			{
				conn.rollback();
			}
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return rowNum;
	}
	
	public int deleteMemberById(String memberId)
	{
		int rowNum=0;
		PreparedStatement pstmt = null;
		try{
			String sql = "delete from family_member_tb where member_id=?";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, memberId);
			rowNum = pstmt.executeUpdate();
			if(rowNum != 0)
			{
				conn.commit();
			}
			else
			{
				conn.rollback();
			}
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return rowNum;
	}
		
	public FamilyMemberVO selectMember(String memberCode)
	{
		FamilyMemberVO vo = null;
		PreparedStatement pstmt = null;
		try{
			String sql = "select * from family_member_tb where member_code=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memberCode);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){
				
				String familyHomecode = rs.getString("family_home_code");
				String memberName = rs.getString("member_name");
				String memberPhone = rs.getString("member_phone");
				String memberEmail = rs.getString("member_email");
				String memberId = rs.getString("member_id");
				String memberPw = rs.getString("member_pw");
				String memberPhoto = rs.getString("member_photo");
				String memberNickName = rs.getString("member_nickname");
				String memberColor = rs.getString("member_color");
				String memberBirth = rs.getString("member_birth");
				String memberRole = rs.getString("member_role");
				
				
				vo = new FamilyMemberVO(memberCode,familyHomecode,memberName,memberPhone,memberEmail,memberId,memberPw,memberPhoto,memberNickName,memberColor,format(new Date()),memberRole );
			}	
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return vo;
	}
	
	public FamilyMemberVO selectMemberById(String memberId)
	{
		FamilyMemberVO vo = null;
		PreparedStatement pstmt = null;
		try{
			String sql = "select * from family_member_tb where member_id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memberId);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){
				String memberCode = rs.getString("member_code");
				String familyHomecode = rs.getString("family_home_code");
				String memberName = rs.getString("member_name");
				String memberPhone = rs.getString("member_phone");
				String memberEmail = rs.getString("member_email");
				
				String memberPw = rs.getString("member_pw");
				String memberPhoto = rs.getString("member_photo");
				String memberNickName = rs.getString("member_nickname");
				String memberColor = rs.getString("member_color");
				String memberBirth = rs.getString("member_birth");
				String memberRole = rs.getString("member_role");
				
				vo = new FamilyMemberVO(memberCode,familyHomecode,memberName,memberPhone,memberEmail,memberId,memberPw,memberPhoto,memberNickName,memberColor,format(new Date()),memberRole );
			}	
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return vo;
	}


	   public static int yearCut(String date){
		      Integer yearInt = new Integer(date.substring(0, 2));
		      return yearInt.intValue()-100;
		      
		   }
		   public static int monthCut(String date){
		      Integer yearInt = new Integer(date.substring(3, 5));
		      return yearInt.intValue()+1;
		   }
		   public static int dateCut(String date){
		      Integer yearInt = new Integer(date.substring(6, 8));
		      return yearInt.intValue();
		   }
	
		   public static String format(Date d){
			    SimpleDateFormat fmt = new SimpleDateFormat("yy-MM-dd");
			    String date = fmt.format(d);
			    return date;
			}
		   	   
	
	public static void main(String[] args)
	{
		FamilyMemberDAO dao = new FamilyMemberDAO();
		
		System.out.println("�߰�"+dao.insertMember("h1", "����x��", "1235454", "aa+s", "id44", "pw1", "��������̶���", "����x�x��", "#ff88ff", new Date(), (byte)1));
		System.out.println("����"+dao.updateMember("m1", "h1", "���翵", "�翵����~", "�翵���̸�", "jaeyoung", "123", "�翵������~", "���翵", "#6688ff", new Date(), (byte)2));
		System.out.println("��ȸ"+dao.selectMember("m1"));
		System.out.println("����"+dao.updateMemberById("h3", "���翵", "�翵����~�ٲ�~", "�翵���̸�ιٲ�~", "jaeyoung", "123", "�翵�������ιٲ�~", "����", "#6688ff", new Date(), (byte)2));
		System.out.println("�Ƶ����ȸ"+dao.selectMemberById("jaeyoung"));
		System.out.println("����"+dao.deleteMember("300029157202637"));
		System.out.println("�Ƶ�λ���"+dao.deleteMemberById("id44"));
		
		
	}

}
