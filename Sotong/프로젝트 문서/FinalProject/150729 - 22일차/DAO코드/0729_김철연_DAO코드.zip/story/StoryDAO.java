package story;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

import menu.MenuDAO;
import menu.MenuVO;
import DBConn.DBConnectionModule;


public class StoryDAO {
	private DBConnectionModule connModule;
	private Connection conn;
	
	public StoryDAO() {
		connModule = DBConnectionModule.getInstance();
		conn = connModule.getConn();
	}
	public StoryDAO(DBConnectionModule connModule, Connection conn) {
		super();
		this.connModule = connModule;
		this.conn = conn;
	}
	
	public String makeMenuCode() {
		Date d = new Date();
		StringTokenizer st = new StringTokenizer(new SimpleDateFormat().format(d),". ");
			
		String year = st.nextToken();
		String month = st.nextToken();
		String day = st.nextToken();
			
		String clientId = "2000"+day+year+month+d.getHours()+d.getMinutes()+d.getSeconds();
		return clientId;
	}
	
	public int insertMenu(String storyCode, String memberCode, String homeCode,
			String sotongCotentsCode, Date storyDate, int storyHeart,
			Date modifyDate, Boolean storyScope) {
		int rowNum = 0;
		PreparedStatement pstmt = null;
		
		String nowDate = sendChangeDate(storyDate);
		
		try{
			String sql = "insert into story_tb values(?,?,?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1,storyCode);
			pstmt.setString(2, memberCode);
			pstmt.setString(3, homeCode);
			pstmt.setString(4,sotongCotentsCode);
			pstmt.setString(5, nowDate);
			pstmt.setInt(6, storyHeart);
			pstmt.setString(7,nowDate);
			if (storyScope) {
				pstmt.setString(8, "�̿�");
			} else {
				pstmt.setString(8, "����");
			}
			
			rowNum = pstmt.executeUpdate();
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return rowNum;
	}
	
	public String sendChangeDate(Date dateTime) {
		int year= dateTime.getYear() - 100;
		String mon = (dateTime.getMonth()+1)>9 ? "" + (dateTime.getMonth()+1) : "0" + (dateTime.getMonth()+1);
		String day = dateTime.getDate()>9 ? "" +dateTime.getDate() : "0" + dateTime.getDate();
	    int hour = dateTime.getHours();
	    int min = dateTime.getMinutes();
	
		return  year + "-" + mon +"-" + day + "-" + hour + ":" + min; 
	}
	public int updateMenu(String storyCode, String memberCode, String homeCode,
			String sotongCotentsCode, int storyHeart, Date modifyDate, Boolean storyScope) {
		
		int rowNum = 0;
		PreparedStatement pstmt = null;
		
		String nowDate = sendChangeDate(modifyDate);
		
		
		try{
			String sql = "update story_tb set member_code=?, homeCode=?, sotong_contents_code =?, "
					+ "story_heart = ?, story_modify_date=?,story_scope = ? where member_code = ?";
			pstmt = conn.prepareStatement(sql);
		
			pstmt.setString(1, memberCode);
			pstmt.setString(2, homeCode);
			pstmt.setString(3, sotongCotentsCode);
			pstmt.setInt(4, storyHeart);
			pstmt.setString(4, nowDate);
			if (storyScope) {
				pstmt.setString(5, "�̿�");
			} else {
				pstmt.setString(5, "����");
			}
			pstmt.setString(6, storyCode);
			
			
			rowNum = pstmt.executeUpdate();
			
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return rowNum;
	}
	
	public int deleteCode(String storyCode){
		int rowNum = 0;
		PreparedStatement pstmt = null;
		try{
			String sql = "delete from story_tb where story_code=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, storyCode);
			rowNum = pstmt.executeUpdate();
			
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return rowNum;
	}
	
	public StoryVO selectCode(String code){
		StoryVO vo = null;
		PreparedStatement pstmt = null;
		try{
			String sql = "select * from stroy_tb where story_code=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, code);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){
				String storyCode = rs.getString("menu_code");
				String memberCode = rs.getString("member_code");
				String homeCode = rs.getString("home_code");
				String sotongCotentsCode = rs.getString("sotong_cotents_code");
				String storyDate = rs.getString("story_date");
				int storyHeart = rs.getInt("story_heart");
				String modifyDate = rs.getString("modify-date");
				String storyScope = rs.getString("story_scope");
				
				
				Date writenDate = changeDate(storyDate);
				Date updateDate = changeDate(modifyDate);
				Boolean scope = false;
				if (storyScope.equals("�̿�")) {
					scope = true;
				}
				vo = new StoryVO(storyCode,memberCode,homeCode,
						sotongCotentsCode,writenDate,storyHeart,updateDate,scope);
			}	
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return vo;
	}
	
	public Date changeDate(String dateTime) {
		int year = Integer.parseInt(dateTime.substring(0,2));
		int mon = Integer.parseInt(dateTime.substring(3,5));
		int date = Integer.parseInt(dateTime.substring(6,8));
		int hour = Integer.parseInt(dateTime.substring(9,11));
		int min = Integer.parseInt(dateTime.substring(12,14));
		
		Date reDate = new Date(year,mon,date);
		reDate.setHours(hour);
		reDate.setMinutes(min);
		return reDate; 
	}
	
	
	public static void main(String[] args) {
		StoryDAO dao = new StoryDAO();
		//System.out.println(dao.deleteCode("story1"));
		System.out.println(dao.insertMenu("cheal", "m2", "h2", "scontents3", new Date(), 50, new Date(), false));
		System.out.println(dao.updateMenu("story1", "m2", "h2", "scontents3", 10, new Date(), true));
		System.out.println(dao.selectCode("story3"));
		
	}
}
