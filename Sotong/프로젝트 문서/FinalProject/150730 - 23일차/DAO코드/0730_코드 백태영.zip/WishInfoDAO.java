package normal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class WishInfoDAO {
private DBConnectionModule connModule;
private Connection conn;

public WishInfoDAO()
{
	connModule=DBConnectionModule.getInstance();
	conn=connModule.getConn();
}

public int insert(String sotongContentsCode,String memberCode,String wishTitle,Date wishDate,Date wishEndDate,byte wishFinish)
{
	int rowNum=0;
	Date date=null;
	PreparedStatement pstmt=null;
	try
	{date=new Date();
		String sql="insert into wish_tb values(?,?,?,?,?,?,?)";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, ""+(date.getYear()-100)+(date.getMonth()+1)+date.getDate()+date.getHours()+date.getMinutes()+date.getSeconds());
		pstmt.setString(2,sotongContentsCode);
		pstmt.setString(3,memberCode);
		pstmt.setString(4,wishTitle);
		System.out.println(wishDate.getYear()+"/"+wishDate.getMonth()+"/"+wishDate.getDate()+"/"+wishDate.getDay());
		System.out.println(wishEndDate.getYear()+"/"+wishEndDate.getMonth()+"/"+wishEndDate.getDate()+"/"+wishEndDate.getDay());
		String date2=changeDate(wishDate);
		String date3=changeDate(wishEndDate);
		pstmt.setString(5,date2);
		pstmt.setString(6,date3);
		if(wishFinish==1)
		{
			pstmt.setString(7,"�Ϸ�");
		}
		else
		{
			pstmt.setString(7,"������");

		}
		rowNum=pstmt.executeUpdate();
	}
	catch(SQLException se)
	{
		se.printStackTrace();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
		}
		catch(SQLException se)
		{
			//se.printStackTrace();
		}
	}
	
	return rowNum;
			
}
public int delete(String wishCode)
{
	int rowNum=0;
	
	PreparedStatement pstmt=null;
	try
	{
		String sql="Delete FROM wish_tb WHERE wish_code=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, wishCode);
		rowNum=pstmt.executeUpdate();
	}
	catch(SQLException se)
	{
		//se.printStackTrace();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
	}
	
	return rowNum;
			
}
public int update(String wishCode,WishInfoVO infoVo)
{
	int rowNum=0;
	
	PreparedStatement pstmt=null;
	try
	{
		
		String sql="UPDATE wish_tb SET sotong_contents_code=?,member_code=?,wish_title=?,wish_date=?,wish_end_date=?, wish_finish=? WHERE wish_code=?";
		
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1,infoVo.getSotongContentsCode());
		pstmt.setString(2,infoVo.getMemberCode());
		pstmt.setString(3,infoVo.getWishTitle());
		String date2=changeDate(infoVo.getWishDate());
		pstmt.setString(4,date2);
		String date3=changeDate(infoVo.getWishEndDate());
		pstmt.setString(5,date3);
		
		Byte isFinished=infoVo.getWishFinish();
		if(isFinished==(byte)1)
		{
			pstmt.setString(6,"�Ϸ�");
		}
		else
		{
			pstmt.setString(6,"������");
		}
		pstmt.setString(7,wishCode);
		rowNum=pstmt.executeUpdate();
	}
	catch(SQLException se)
	{
		se.printStackTrace();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
	}
	
	return rowNum;
			
}
public WishInfoVO select(String wishCode)
{
	int rowNum=0;
	
	PreparedStatement pstmt=null;
	WishInfoVO infoVo=null;
	try
	{
		
		String sql="SELECT * FROM wish_tb where WISH_CODE=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, wishCode);
		ResultSet rs=pstmt.executeQuery();
		rs.next();
		infoVo=new WishInfoVO();
		infoVo.setWishCode(rs.getString("wish_code"));
		infoVo.setSotongContentsCode(rs.getString("sotong_contents_code"));
		infoVo.setMemberCode(rs.getString("member_code"));
		infoVo.setWishTitle(rs.getString("wish_title"));
	
		String date=rs.getString("wish_date");
		String year=date.substring(0,2);
		String month=date.substring(3,5);
		String day=date.substring(6,8);
		infoVo.setWishDate(new Date());
		System.out.println(year+"/"+month+"/"+day);
		Date dt=new Date(Integer.parseInt(year.trim())+100,Integer.parseInt(month.trim())-1,Integer.parseInt(day.trim()));
		infoVo.setWishDate(dt);
		date=rs.getString("wish_end_date");
		year=date.substring(0,2);
		month=date.substring(3,5);
		day=date.substring(6,8);
		dt=new Date(Integer.parseInt(year.trim())+100,Integer.parseInt(month.trim())-1,Integer.parseInt(day.trim()));
		infoVo.setWishEndDate(dt);
		System.out.println("aa"+dt.getYear()+"/"+dt.getMonth()+"/"+dt.getDate()+"/"+dt.getDay());
		String str=rs.getString("wish_Finish");
		if(str.equals("�Ϸ�"))
		{
			infoVo.setWishFinish((byte)1);
		}
		else
		{
			infoVo.setWishFinish((byte)0);
		}
	
		rowNum=pstmt.executeUpdate();
	}
	catch(SQLException se)
	{
		se.printStackTrace();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
	}
	
	return infoVo;
			
}

public String changeDate(Date date)
{
	String dt;
	if(date.getDate()>=9)
	{
		if(date.getMonth()>=10)
		{
		dt=""+(date.getYear()-100)+"-"+(date.getMonth()+1)+"-"+(date.getDate());
		}
		else
		{
		dt=""+(date.getYear()-100)+"-0"+(date.getMonth()+1)+"-"+(date.getDate());
		}
	}
	else
	{
		if(date.getMonth()>=9)
		{
		dt=""+(date.getYear()-100)+"-"+(date.getMonth()+1)+"-0"+(date.getDate());
		}
		else
		{
		dt=""+(date.getYear()-100)+"-0"+(date.getMonth()+1)+"-0"+(date.getDate());
		}
	}
	return dt;
}
public static void main(String args[])
{
	WishInfoDAO dao=new WishInfoDAO();
	//dao.delete("1563091630");
	dao.insert("scontents4", "m3", "���������׽�Ʈ1", new Date(),new Date(115,6,30),(byte)0);
	//dao.update("��",new WishInfoVO("w4","scontents1","m2","test2",new Date(),new Date(115,12,1),(byte)1));//����ڰ� ��¥ ������ ex)2015-7-30�Է½� 115,6,30���� �ʱ�ȭ (�������� -1900�� ��, ������ -1�Ѱ�.)
	System.out.println(dao.select("w2")); 
	
}
}
