package normal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LetterInfoViewDAO {
private DBConnectionModule connModule;
private Connection conn;

public LetterInfoViewDAO()
{
	connModule=DBConnectionModule.getInstance();
	conn=connModule.getConn();
}

public LetterInfoViewVO select(String letterCode)
{
	int rowNum=0;
	
	PreparedStatement pstmt=null;
	LetterInfoViewVO viewVO=null;
	try
	{
		
		String sql="SELECT * FROM letter_view where LETTER_CODE=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, letterCode);
		ResultSet rs=pstmt.executeQuery();
		rs.next();
		viewVO=new LetterInfoViewVO();
		
		viewVO.setLetterCode(rs.getString("letter_code"));
		viewVO.setSender(rs.getString("sender"));
		viewVO.setReceiver(rs.getString("receiver"));
		viewVO.setLetterTitle(rs.getString("letter_title"));
		
		String date=rs.getString("send_date");
		String year=date.substring(0,2);
		String month=date.substring(3,5);
		String day=date.substring(6,8);
		Date sendDate=new Date(Integer.parseInt(year.trim())+100,Integer.parseInt(month.trim())-1,Integer.parseInt(day.trim()));
		
		viewVO.setSendDate(sendDate);
		viewVO.setImageName(rs.getString("image_name"));
		
		date=rs.getString("image_written_date");
		year=date.substring(0,2);
		month=date.substring(3,5);
		day=date.substring(6,8);
		Date imageWrittenDate=new Date(Integer.parseInt(year.trim())+100,Integer.parseInt(month.trim())-1,Integer.parseInt(day.trim()));
		
		viewVO.setImageWrittenDate(imageWrittenDate);
		viewVO.setEmoticonName(rs.getString("emoticon_name"));
		viewVO.setEmoticonRoute(rs.getString("emoticon_route"));
		
		//System.out.println(year+"/"+month+"/"+day);
		
		rowNum=pstmt.executeUpdate();
	}
	catch(SQLException se)
	{
		se.printStackTrace();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
	}
	
	return viewVO;
			
}
public List<LetterInfoViewVO> selectByReceiver(String receiverCode)
{
	int rowNum=0;
	
	PreparedStatement pstmt=null;
	List<LetterInfoViewVO> list=new ArrayList<LetterInfoViewVO>();
	LetterInfoViewVO viewVO=null;
	try
	{
		
		String sql="select * from letter_view where Receiver=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, receiverCode);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next())
		{
		viewVO=new LetterInfoViewVO();
		viewVO.setLetterCode(rs.getString("letter_code"));
		viewVO.setSender(rs.getString("sender"));
		viewVO.setReceiver(rs.getString("receiver"));
		viewVO.setLetterTitle(rs.getString("letter_title"));
		
		String date=rs.getString("send_date");
		String year=date.substring(0,2);
		String month=date.substring(3,5);
		String day=date.substring(6,8);
		Date sendDate=new Date(Integer.parseInt(year.trim())+100,Integer.parseInt(month.trim())-1,Integer.parseInt(day.trim()));
		
		viewVO.setSendDate(sendDate);
		viewVO.setImageName(rs.getString("image_name"));
		
		date=rs.getString("image_written_date");
		year=date.substring(0,2);
		month=date.substring(3,5);
		day=date.substring(6,8);
		Date imageWrittenDate=new Date(Integer.parseInt(year.trim())+100,Integer.parseInt(month.trim())-1,Integer.parseInt(day.trim()));
		
		viewVO.setImageWrittenDate(imageWrittenDate);
		viewVO.setEmoticonName(rs.getString("emoticon_name"));
		viewVO.setEmoticonRoute(rs.getString("emoticon_route"));
		
		//System.out.println(year+"/"+month+"/"+day);
		list.add(viewVO);
		}
		rowNum=pstmt.executeUpdate();
	}
	catch(SQLException se)
	{
		se.printStackTrace();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
	}
	
	return list;
			
}

public static void main(String args[])
{
	LetterInfoViewDAO dao=new LetterInfoViewDAO();
	//dao.delete("201563202230");
	LetterInfoViewVO view=dao.select("l1");
	//dao.update("15113193819", dao.select("l2"));
	//System.out.println(view);
	//System.out.println(view.getSendDate().getYear()+"/"+view.getSendDate().getMonth()+"/"+view.getSendDate().getDate()+"/"+view.getSendDate().getDay());
	//System.out.println(view.getImageWrittenDate().getYear()+"/"+view.getImageWrittenDate().getMonth()+"/"+view.getImageWrittenDate().getDate()+"/"+view.getImageWrittenDate().getDay());
	System.out.println(dao.selectByReceiver("m4"));
}
}
