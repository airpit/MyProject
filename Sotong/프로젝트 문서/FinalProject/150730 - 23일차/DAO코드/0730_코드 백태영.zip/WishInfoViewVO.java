package normal;

import java.util.Date;

public class WishInfoViewVO {
	private String wishCode;
	private String memberNickName;
	private String emoticonName;
	private String emoticonRoute;
	private String imageName;
	private Date imageWrittenDate;
	private String wishTitle;
	private Date wishDate;
	private Date wishEndDate;
	private byte wishFinish;
	public WishInfoViewVO()
	{
		
	}
	public WishInfoViewVO(String wishCode, String memberNickName,
			String emoticonName, String emoticonRoute, String imageName,
			Date imageWrittenDate, String wishTitle, Date wishDate,
			Date wishEndDate, byte wishFinish) {
		this.wishCode = wishCode;
		this.memberNickName = memberNickName;
		this.emoticonName = emoticonName;
		this.emoticonRoute = emoticonRoute;
		this.imageName = imageName;
		this.imageWrittenDate = imageWrittenDate;
		this.wishTitle = wishTitle;
		this.wishDate = wishDate;
		this.wishEndDate = wishEndDate;
		this.wishFinish = wishFinish;
	}
	public String getWishCode() {
		return wishCode;
	}
	public void setWishCode(String wishCode) {
		this.wishCode = wishCode;
	}
	public String getMemberNickName() {
		return memberNickName;
	}
	public void setMemberNickName(String memberNickName) {
		this.memberNickName = memberNickName;
	}
	public String getEmoticonName() {
		return emoticonName;
	}
	public void setEmoticonName(String emoticonName) {
		this.emoticonName = emoticonName;
	}
	public String getEmoticonRoute() {
		return emoticonRoute;
	}
	public void setEmoticonRoute(String emoticonRoute) {
		this.emoticonRoute = emoticonRoute;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public Date getImageWrittenDate() {
		return imageWrittenDate;
	}
	public void setImageWrittenDate(Date imageWrittenDate) {
		this.imageWrittenDate = imageWrittenDate;
	}
	public String getWishTitle() {
		return wishTitle;
	}
	public void setWishTitle(String wishTitle) {
		this.wishTitle = wishTitle;
	}
	public Date getWishDate() {
		return wishDate;
	}
	public void setWishDate(Date wishDate) {
		this.wishDate = wishDate;
	}
	public Date getWishEndDate() {
		return wishEndDate;
	}
	public void setWishEndDate(Date wishEndDate) {
		this.wishEndDate = wishEndDate;
	}
	public byte getWishFinish() {
		return wishFinish;
	}
	public void setWishFinish(byte wishFinish) {
		this.wishFinish = wishFinish;
	}
	
	public String toString() {
		return "WishInfoViewVO [wishCode=" + wishCode + ", memberNickName="
				+ memberNickName + ", emoticonName=" + emoticonName
				+ ", emoticonRoute=" + emoticonRoute + ", imageName="
				+ imageName + ", imageWrittenDate=" + imageWrittenDate
				+ ", wishTitle=" + wishTitle + ", wishDate=" + wishDate
				+ ", wishEndDate=" + wishEndDate + ", wishFinish=" + wishFinish
				+ "]";
	}
	
}
