package normal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class WishInfoViewDAO {
private DBConnectionModule connModule;
private Connection conn;

public WishInfoViewDAO()
{
	connModule=DBConnectionModule.getInstance();
	conn=connModule.getConn();
}

public WishInfoViewVO select(String wishCode)
{
	int rowNum=0;
	
	PreparedStatement pstmt=null;
	WishInfoViewVO viewVO=null;
	try
	{
		
		String sql="SELECT * FROM wish_view where wish_CODE=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, wishCode);
		ResultSet rs=pstmt.executeQuery();
		rs.next();
		viewVO=new WishInfoViewVO();
		
		viewVO.setWishCode(rs.getString("wish_code"));
		viewVO.setMemberNickName(rs.getString("member_nickname"));
		viewVO.setEmoticonName(rs.getString("emoticon_name"));
		viewVO.setEmoticonRoute(rs.getString("emoticon_route"));
		viewVO.setImageName(rs.getString("image_name"));
		String date=rs.getString("image_written_date");
		String year=date.substring(0,2);
		String month=date.substring(3,5);
		String day=date.substring(6,8);
		viewVO.setImageName(rs.getString("image_name"));
		
		
		
		date=rs.getString("image_written_date");
		year=date.substring(0,2);
		month=date.substring(3,5);
		day=date.substring(6,8);
		Date imageWrittenDate=new Date(Integer.parseInt(year.trim())+100,Integer.parseInt(month.trim())-1,Integer.parseInt(day.trim()));
		
		viewVO.setImageWrittenDate(imageWrittenDate);
		
		viewVO.setWishTitle(rs.getString("wish_title"));
		date=rs.getString("wish_date");
		year=date.substring(0,2);
		month=date.substring(3,5);
		day=date.substring(6,8);
		Date wishDate=new Date(Integer.parseInt(year.trim())+100,Integer.parseInt(month.trim())-1,Integer.parseInt(day.trim()));
		viewVO.setWishDate(wishDate);
		
		date=rs.getString("wish_end_date");
		year=date.substring(0,2);
		month=date.substring(3,5);
		day=date.substring(6,8);
		Date wishEndDate=new Date(Integer.parseInt(year.trim())+100,Integer.parseInt(month.trim())-1,Integer.parseInt(day.trim()));
		
		viewVO.setWishEndDate(wishEndDate);
		
		String isFinished=rs.getString("wish_finish");
		if(isFinished.equals("�Ϸ�"))
		{
			viewVO.setWishFinish((byte)1);
		}
		else
		{
			viewVO.setWishFinish((byte)0);
		}
		
		//System.out.println(year+"/"+month+"/"+day);
		
		rowNum=pstmt.executeUpdate();
	}
	catch(SQLException se)
	{
		se.printStackTrace();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			if(pstmt!=null)
			{
				pstmt.close();
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
	}
	
	return viewVO;
			
}

public static void main(String args[])
{
	WishInfoViewDAO dao=new WishInfoViewDAO();
	//dao.delete("201563202230");
	WishInfoViewVO view=dao.select("w2");
	//dao.update("15113193819", dao.select("l2"));
	System.out.println(view);
	System.out.println(view.getImageWrittenDate().getYear()+"/"+view.getImageWrittenDate().getMonth()+"/"+view.getImageWrittenDate().getDate()+"/"+view.getImageWrittenDate().getDay());
	System.out.println(view.getWishDate().getYear()+"/"+view.getWishDate().getMonth()+"/"+view.getWishDate().getDate()+"/"+view.getWishDate().getDay());
	System.out.println(view.getWishEndDate().getYear()+"/"+view.getWishEndDate().getMonth()+"/"+view.getWishEndDate().getDate()+"/"+view.getWishEndDate().getDay());

}
}
