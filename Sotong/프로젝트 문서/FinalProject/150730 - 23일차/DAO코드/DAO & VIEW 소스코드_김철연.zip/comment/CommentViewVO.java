package comment;

import java.util.Date;

public class CommentViewVO {
	
	private String commentCode;
	private String commentContents;
	
	private Date commentDate;
	private String emoticonName;
	
	private String familyDiaryCode;
	private Date familyDiaryDate;
	
	private String storyCode;
	private String emoticonRoute;
	
	public CommentViewVO() {
		super();
	}
	public CommentViewVO(String commentCode, String commentContents,
			Date commentDate, String emoticonName, String familyDiaryCode,
			Date familyDiaryDate, String storyCode, String emoticonRoute) {
		super();
		this.commentCode = commentCode;
		this.commentContents = commentContents;
		this.commentDate = commentDate;
		this.emoticonName = emoticonName;
		this.familyDiaryCode = familyDiaryCode;
		this.familyDiaryDate = familyDiaryDate;
		this.storyCode = storyCode;
		this.emoticonRoute = emoticonRoute;
		
		System.out.println("ddd')");
	}
	public String getCommentCode() {
		return commentCode;
	}
	public void setCommentCode(String commentCode) {
		this.commentCode = commentCode;
	}
	public String getCommentContents() {
		return commentContents;
	}
	public void setCommentContents(String commentContents) {
		this.commentContents = commentContents;
	}
	public Date getCommentDate() {
		return commentDate;
	}
	public void setCommentDate(Date commentDate) {
		this.commentDate = commentDate;
	}
	public String getEmoticonName() {
		return emoticonName;
	}
	public void setEmoticonName(String emoticonName) {
		this.emoticonName = emoticonName;
	}
	public String getFamilyDiaryCode() {
		return familyDiaryCode;
	}
	public void setFamilyDiaryCode(String familyDiaryCode) {
		this.familyDiaryCode = familyDiaryCode;
	}
	public Date getFamilyDiaryDate() {
		return familyDiaryDate;
	}
	public void setFamilyDiaryDate(Date familyDiaryDate) {
		this.familyDiaryDate = familyDiaryDate;
	}
	public String getStoryCode() {
		return storyCode;
	}
	public void setStoryCode(String storyCode) {
		this.storyCode = storyCode;
	}
	public String getEmoticonRoute() {
		return emoticonRoute;
	}
	public void setEmoticonRoute(String emoticonRoute) {
		this.emoticonRoute = emoticonRoute;
	}
	
	
	public String toString() {
		return "CommentViewVO [commentCode=" + commentCode
				+ ", commentContents=" + commentContents + ", commentDate="
				+ commentDate + ", emoticonName=" + emoticonName
				+ ", familyDiaryCode=" + familyDiaryCode + ", familyDiaryDate="
				+ familyDiaryDate + ", storyCode=" + storyCode
				+ ", emoticonRoute=" + emoticonRoute + "]";
	}
}
