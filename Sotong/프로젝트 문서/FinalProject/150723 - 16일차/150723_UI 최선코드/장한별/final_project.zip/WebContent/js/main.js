$(document).ready(function(){
    $("#loginImg").mouseover(function(){
        $("#myLogin").modal();
    });
    
    $("#signupImg").mouseover(function(){
        $("#mySignup").modal();
    });  
    
    $("#inHomeImg").click(function(){
    	$("#loginImg, #signupImg").fadeIn();
    });   
    
    
    $("#inImg").click(function() {
    	if($("#userId").val()=="test" && $("#userPw").val()=="123")
    		{
    			alert("로그인 성공");
    			return true;
    		}
    	else
    		{
    			alert("로그인 실패");
    			return false;
    		}
    	
    });
    
    $("#okImg").click(function() {
    	alert("회원가입");
    	return false;
    });
});