$(document).ready(function(){
	$("#deleteBtn").click(function(){
		alert("삭제하시겠습니까?");
	});
	
	$("#writeBtn").click(function(){
		alert("글 쓰기 클릭");
	});

});