$(document).ready(function(){
    $(".show-sidebar").click(function(){
        $("#sidebar").toggleClass("side-menu");
    });
});