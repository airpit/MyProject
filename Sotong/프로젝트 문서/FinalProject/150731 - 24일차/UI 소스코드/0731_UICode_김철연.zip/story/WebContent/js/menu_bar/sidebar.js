$(document).ready(function(){
    $("#showSidebar").click(function(){	
        
        if ($("#sidebar").prop("display","none"))
        {
        	$("#sidebar").toggle();
        }

    });
});