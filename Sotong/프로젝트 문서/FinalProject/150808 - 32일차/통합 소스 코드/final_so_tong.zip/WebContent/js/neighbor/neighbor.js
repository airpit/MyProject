jQuery.fn.extend({
    listrap: function () {
        var listrap = this;
        listrap.getSelection = function () {
            var selection = new Array();
            listrap.children("li.active").each(function (ix, el) {
                selection.push($(el)[0]);
            });
            return selection;
        }
        var toggle = "li .listrap-toggle ";
        var selectionChanged = function() {
            $(this).parent().parent().toggleClass("active");
            listrap.trigger("selection-changed", [listrap.getSelection()]);
        }
        $(listrap).find(toggle + "img").on("click", selectionChanged);
        $(listrap).find(toggle + "span").on("click", selectionChanged);
        return listrap;
    }
});

$(document).ready(function(){
	
	$('#neighborTab a[href="#showNeighbor"]').click(function(e) {
		e.preventDefault();
		$(this).tab('show');
	});
	
	$('#neighborTab a[href="#searchNeighbor"]').click(function(e) {
		e.preventDefault();
		$(this).tab('show');
	});	
	

	$("ul.nav-tabs > li > a").on("shown.bs.tab", function (e) {
	        var id = $(e.target).attr("href").substr(1);
	        window.location.hash = id;
	 });
	    // on load of the page: switch to the currently selected tab
	    var hash = window.location.hash;
	$('#neighborTab a[href="' + hash + '"]').tab('show');
	
	//검색 버튼 클릭
	$('#searchBtn').click(function(){
//		alert($('#search-category :selected').val());
		var searchCategory = $("#search-category :selected").val();
		var searchWord2 = $("#searchWord").val();
		var searchWord =escape(encodeURIComponent(searchWord2));
//		$.ajax({
//			type:"GET",
//	        url:"searchNeighbor.do",
//	        data:{searchCategory:searchCategory, searchWord: searchWord},
//	        contentType: "application/x-www-form-urlencoded; charset=UTF-8", 
//	        success : function(result){
//				alert("검색됨" + result);
//				}	        
//		});
		$("#search-result-list").empty();
		$.ajax({
			type:"POST",
	        url:"searchNeighbor.do",
	        data:$("#neighbor-search").serialize(),
	        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
	        dataType: "json",
	        success : function(result){	        	
	        	$.each(result, function(index, value){
	        		var html ='';
	        		html+= '<div id="neighbor-home-info">';
	        		html+= '<form id="neighbor-form"'+index+'>';
	        		html+= '<div id="neighbor-home"> ';
	        		html+= '<img src="img/neighbor/home.png" id="homeImg" width="47px" height="47px"/>';
	        		html+= '<label>'+result[index].familyHomeName+'</label>';
	        		html+= '</div>';
	        		
	        		if(result[index].memberRole=='1')
	        		{
	        			html+= '<div id="neighbor-family-info"><div id="manager_level" class="form-group"><img src="img/myhome/manager.png" id="managerIcon" alt="매니저"/></div>';
	        		}
	        		else
	        		{
	        			html+= '<div id="neighbor-family-info"><div id="manager_level" class="form-group"><img src="img/myhome/hearts.png" id="familyIcon" alt="가족"/></div>';
	        		}
	        		
	        		html+= '<div id="profile_pic" class="form-group"><img src="'+result[index].memberPhoto+'" id="profileImg" alt="프로필사진" class="img-circle"/></div>';
	        		html+= '<div id="profile_info" class="form-group"><label>'+result[index].memberNickName+'</label><span class="glyphicon glyphicon-gift" aria-hidden="true"  style="color: #FF66CC"></span>생일 : '+result[index].memberBirth+'</div></div></form></div>';
	        		$("#search-result-list").append(html);
	        	})
	        },

	});
	});

	
//	$(".neighbor-list-li .neighbor-home-a").click(function(){
//		
//		var index = $("li .neighbor-home-a").index(this);
////		alert($("#homeCode").val());
//		$("#neighbor-form").submit();
//	});

	//클릭 시 이웃 보기
	$("#neighbor-list-ul li").click(function(){
		var index = $("#neighbor-list-ul .neighbor-list-li").index(this);
		$("#neighbor-form"+index).submit();
	});
	
	$(".listrap").listrap().on("selection-changed", function (event, selection) {
        console.log(selection);
    });

});
