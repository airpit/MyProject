$(document).ready(function(){
			
		$("#delImg").click(function(){
			alert("가족구성원 삭제 클릭됨");
		});
		
		$("#managerImg").mouseover(function(){
			
		});
		
		$("#managerImg").click(function(){
			alert("매니저권한 위임 선택됨");
		});
		
		$("#personColor").click(function(){
			alert(this.val());
		});
	});
