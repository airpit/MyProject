package control.schedule;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import manager.schedule.ScheduleManager;

import com.google.gson.Gson;

import dao.home.FamilyMemberVO;
import dao.schedule.ScheduleVO;

/**
 * Servlet implementation class ScheduleServlet
 */
@WebServlet(name="ScheduleServelt", urlPatterns={"/schedule.do", "/addSchedule.do", "/modifySchedule.do", "/deleteSchedule.do"})
public class ScheduleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ScheduleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html charset=UTF-8");
		process(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html charset=UTF-8");	
		process(request,response);
	}
	private void process(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		
		String uri = request.getRequestURI();
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex+1);
		
		if(action.equals("schedule.do"))
		{
			requestSimpleScheduleList(request,response);
		}
		else if(action.equals("addSchedule.do"))
		{
			requestAddScheduleList(request,response);
		}
	}
	
	private void requestSimpleScheduleList(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		HttpSession session = request.getSession();
		FamilyMemberVO userInfo = (FamilyMemberVO)session.getAttribute("userInfo");
		System.out.println("���� ��� : "+ userInfo.getMemberCode());
		
		ScheduleManager manager = new ScheduleManager();
		ScheduleVO[] voList = manager.getSimpleIndividualScheduleInfoListWeb(userInfo.getMemberCode(), "15", "08");

		if(voList != null)
		{
			System.out.println("���� ���" + voList.length);
			for(int i=0; i<voList.length;i++)
			{
				System.out.println(voList[i].getMemberCode());
			}
			
			String result = new Gson().toJson(voList);
			response.setContentType("text/plain");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().write(result);
		}
		else
		{
			RequestDispatcher rd = request.getRequestDispatcher("JSP/schedule/selfCalendar.jsp");
			rd.forward(request, response);
		}
	}
	
	private void requestAddScheduleList(HttpServletRequest request, HttpServletResponse response)
	{
		
	}

}
