$(document).ready(function(){
	
	var now = new Date();
    var year= now.getFullYear();
    var mon = (now.getMonth()+1)>9 ? ''+(now.getMonth()+1) : '0'+(now.getMonth()+1);
    var day = now.getDate()>9 ? ''+now.getDate() : '0'+now.getDate();
            
    var chan_val = '작성날짜: ' + year + '-' + mon + '-' + day;
    $('#my-diary-board-read-write-date').val(chan_val);
    
    
	//게시글 목록 버튼 이벤트 처리 =====================================================
		$('#up-btn').on('click',function() {
			alert("위로 가기 버튼 클릭함");
		});
		
		$('#down-btn').on('click',function() {
			alert("내려가기 버튼 클릭함");
		});
		
		$('#my-diary-list-title-btn').on('click',function() {
			var wrteDate = $('#my-diary-list-date').val();
			var wrteTitle = $('#my-diary-list-title-btn').val();
				
			alert(wrteDate + "   " + wrteTitle);
		});
		
	//게시글 목록 버튼 이벤트 처리 =====================================================

	
	//게시글 마우스 이베튼 처리 =======================================================
		$('#addPhotoBtn').hover(function(){
			//마우스를 삭제 버튼으로 올리시 이베튼 발생
			$("#addPhotoLetter").css("display", "block");
		});
		$('#backBtn').hover(function(){
			//마우스를 수정 버튼으로 올리시 이베튼 발생
			$("#back-letter").css("display", "block");
		});
		$('#okBtn').hover(function(){
			//마우스를 글쓰기 버튼으로 올리시 이베튼 발생
			$("#okLetter").css("display", "block");
		});
		$('#addPhotoBtn').mouseout(function(){
			//마우스를 요소에서 제거 하면 발생하는 함수
			$("#addPhotoLetter").css("display", "none");
		});
		$('#backBtn').mouseout(function(){
			//마우스를 요소에서 제거 하면 발생하는 함수
			$("#backLetter").css("display", "none");
		});
		$('#okBtn').mouseout(function(){
			//마우스를 요소에서 제거 하면 발생하는 함수
			$("#okLetter").css("display", "none");
		});
	//게시글 마우스 이베튼 처리 =======================================================		
	
		
	//게시물 버튼 이벤트 처리 ========================================================
		$('#addPhotoBtn').on('click',addPhotoBtn);
			//마우스를 삭제 버튼으로 클릭 시 이베튼 발생
		
		$('#backBtn').on('click',backBtn);
			//마우스를 수정 버튼으로 콜릭 시 이베튼 발생
			
		$('#okBtn').on('click',okBtn);
			//작성 확인 클릭 시 okBtn 함수를 호출한다.
	//게시물 버튼 이벤트 처리 ========================================================
});

function addPhotoBtn(){
	//사진 추가
	
	$("#addPhotoLetter").css("display", "none");
	
	alert('사진 추가 버튼 클릭');
	
}

function backBtn() {
	//돌아 가는 버튼 되돌아가기
	
	$("#backLetter").css("display", "none");
	
	alert('되돌아가자');
}

function okBtn() {
	//작성 누르면 서버로 가서 등록 한다.
	
	$("#okLetter").css("display", "none");
	
	var writeDate = $('#my-diary-board-read-write-date').val();
	var title = $('#my-diary-title').val();
	var content = $('#my-diary-board-read-content-textarea').val();
	
	if (title == "") {
		alert('제목을 입력하세요');
	} else if (content == "") {
		alert("내용을 입력하세요");
	} else {
		alert(writeDate + '\n' + title + '\n' + content);
	}
}