$(document).ready(function(){
    $("#showSidebar").click(function(){	
        
        if ($("#sidebar").prop("display","none"))
        {
        	$("#sidebar").toggle();
        }

    });
    /*
    $("#storyBoard").hover(function(){
    	$("#story-sub-menu").css("display","block");  
    });
    $("#storyBoard").mouseout(function(){
    	$("#story-sub-menu").css("display","none");  
    });
    
    $("#diaryBoard").hover(function(){
    	$("#diary-sub-menu").css("display","block");  
    });
    $("#diaryBoard").mouseout(function(){
    	$("#diary-sub-menu").css("display","none");  
    });
    
    $("#scheduleBoard").hover(function(){
    	$("#schedule-sub-menu").css("display","block");  
    });
    $("#scheduleBoard").mouseout(function(){
    	$("#schedule-sub-menu").css("display","none");  
    });
    */
    
  
});