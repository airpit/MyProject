package normal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ConnectionWaitingViewDAO {
	private DBConnectionModule connModule;
	private Connection conn;

	public ConnectionWaitingViewDAO()
	{
		connModule=DBConnectionModule.getInstance();
		conn=connModule.getConn();
	}
	public ConnectionWaitingViewVO[] selectGetConnectionWaitingList(String homeCode)
	{
		PreparedStatement pstmt=null;
		List<ConnectionWaitingViewVO> list=new ArrayList<ConnectionWaitingViewVO>();
		ConnectionWaitingViewVO[] voList=null;
		ConnectionWaitingViewVO vo=null;
		try
		{
			
			String sql="SELECT * FROM connection_waiting_view where receiver_home_code=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, homeCode);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				
			String senderCode=rs.getString("sender_home_code");
			String senderHomeName=rs.getString("family_home_name");
			String senderHomeManagerName=rs.getString("member_name");
			String receiverCode=rs.getString("receiver_home_code");
			
				
			vo=new ConnectionWaitingViewVO(senderCode,senderHomeName,senderHomeManagerName,receiverCode);
			
			
			list.add(vo);
			}
			voList=new ConnectionWaitingViewVO[list.size()];
			for(int i=0;i<list.size();i++)
			{
				voList[i]=list.get(i);
			}
			
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(pstmt!=null)
				{
					pstmt.close();
				}
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
		}
		
		return voList;
	}
	public static void main(String args[])
	{
		ConnectionWaitingViewDAO dao=new ConnectionWaitingViewDAO();
		ConnectionWaitingViewVO[] vo=dao.selectGetConnectionWaitingList("h2");
		for(int i=0;i<vo.length;i++)
		{
			System.out.println(vo[i]);
		}
	}
}
