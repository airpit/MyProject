package normal;

import java.util.Date;

public class ConnectionWaitingVO {
	private String watingCode;
	private String receiverHomeCode;
	private String senderHomeCode;
	private Date waitingDate;
	public ConnectionWaitingVO()
	{}
	public ConnectionWaitingVO(String watingCode, String receiverHomeCode,
			String senderHomeCode, Date waitingDate) {
		this.watingCode = watingCode;
		this.receiverHomeCode = receiverHomeCode;
		this.senderHomeCode = senderHomeCode;
		this.waitingDate = waitingDate;
	}
	public String getWatingCode() {
		return watingCode;
	}
	public void setWatingCode(String watingCode) {
		this.watingCode = watingCode;
	}
	public String getReceiverHomeCode() {
		return receiverHomeCode;
	}
	public void setReceiverHomeCode(String receiverHomeCode) {
		this.receiverHomeCode = receiverHomeCode;
	}
	public String getSenderHomeCode() {
		return senderHomeCode;
	}
	public void setSenderHomeCode(String senderHomeCode) {
		this.senderHomeCode = senderHomeCode;
	}
	public Date getWaitingDate() {
		return waitingDate;
	}
	public void setWaitingDate(Date waitingDate) {
		this.waitingDate = waitingDate;
	}
	@Override
	public String toString() {
		return "ConnectionWaitingVO [watingCode=" + watingCode
				+ ", receiverHomeCode=" + receiverHomeCode
				+ ", senderHomeCode=" + senderHomeCode + ", waitingDate="
				+ waitingDate + "]";
	}
	
	
}
