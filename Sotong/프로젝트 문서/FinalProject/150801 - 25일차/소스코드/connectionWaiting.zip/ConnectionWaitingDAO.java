package normal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ConnectionWaitingDAO {
	private DBConnectionModule connModule;
	private Connection conn;
	
	public ConnectionWaitingDAO()
	{
		connModule=DBConnectionModule.getInstance();
		conn=connModule.getConn();
	}
	/*public String makeWaitingCode()
	{
		
		int cnt=0,rowNum;
		String code=null;
		PreparedStatement pstmt=null;
		try
		{
			String sql="select count(*) from connection_waiting_tb";
			pstmt=conn.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			cnt=rs.getInt("count(*)");
			code="w"+(cnt+1);
			sql="select waiting_code from connection_waiting_tb";
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				if(code.equals(rs.getString("waiting_code")))
					{
						cnt+=1;
						code="w"+cnt;
					}
			}
		
		}
		catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(pstmt!=null)
				{
					pstmt.close();
				}
			}
			catch(SQLException e)
			{
				
			}
		}
		return code;
	}*/
	
	public int insertConnectionWaiting(String homeCode,String neighborCode)
	{
		int rowNum=0;
		
		PreparedStatement pstmt=null;
		try
		{
			String sql="insert into connection_waiting_tb values(?,?,?,?)";
			pstmt=conn.prepareStatement(sql);
			
			
			pstmt.setString(1, "cw"+new Date().getSeconds());
			pstmt.setString(2,homeCode);
			pstmt.setString(3,neighborCode);
			pstmt.setString(4,changeDate(new Date()));
			rowNum=pstmt.executeUpdate();
				
		}
		catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(pstmt!=null)
				{
					pstmt.close();
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		return rowNum;
		
	}
	public int deleteConnectionWaiting(String waitingCode)
	{
		int rowNum=0;
		PreparedStatement pstmt=null;
		try
		{
			String sql="delete from connection_waiting_tb where waiting_code=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, waitingCode);
			rowNum=pstmt.executeUpdate();
				
		}
		catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(pstmt!=null)
				{
					pstmt.close();
				}
			}
			catch(SQLException e)
			{
				
			}
		}
		return rowNum;
	}
	public int deleteConnectionWaiting(String homeCode,String neighborCode)
	{
		int rowNum=0;
		PreparedStatement pstmt=null;
		try
		{
			String sql="delete from connection_waiting_tb where receiver_home_code=? AND sender_home_code=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, homeCode);
			pstmt.setString(2, neighborCode);
			rowNum=pstmt.executeUpdate();
				
		}
		catch(SQLException sqe)
		{
			sqe.printStackTrace();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(pstmt!=null)
				{
					pstmt.close();
				}
			}
			catch(SQLException e)
			{
				
			}
		}
		return rowNum;
	}
	public ConnectionWaitingVO[] selectGetConnectionWaitingList(String homeCode)
	{
		
		PreparedStatement pstmt=null;
		List<ConnectionWaitingVO> list=new ArrayList<ConnectionWaitingVO>();
		ConnectionWaitingVO[] voList=null;
		ConnectionWaitingVO vo=null;
		try
		{
			
			String sql="SELECT * FROM connection_waiting_tb where receiver_home_code=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, homeCode);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				
			String wCode=rs.getString("waiting_code");
			String receiver=rs.getString("receiver_home_code");
			String sender=rs.getString("sender_home_code");
			String sendDate=rs.getString("waiting_date");
			
			Date date=new Date(Integer.parseInt(sendDate.substring(0,2))-100,Integer.parseInt(sendDate.substring(3,5))+1,Integer.parseInt(sendDate.substring(6,8)));
			
			vo=new ConnectionWaitingVO(wCode, receiver, sender, date);
			
			
			list.add(vo);
			}
			voList=new ConnectionWaitingVO[list.size()];
			for(int i=0;i<list.size();i++)
			{
				voList[i]=list.get(i);
			}
			
			
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(pstmt!=null)
				{
					pstmt.close();
				}
			}
			catch(SQLException se)
			{
				se.printStackTrace();
			}
		}
		
		return voList;
	}
	public String changeDate(Date date)
	{
		String dt;
		if(date.getDate()>=9)
		{
			if(date.getMonth()>=10)
			{
			dt=""+(date.getYear()-100)+"-"+(date.getMonth()+1)+"-"+(date.getDate());
			}
			else
			{
			dt=""+(date.getYear()-100)+"-0"+(date.getMonth()+1)+"-"+(date.getDate());
			}
		}
		else
		{
			if(date.getMonth()>=9)
			{
			dt=""+(date.getYear()-100)+"-"+(date.getMonth()+1)+"-0"+(date.getDate());
			}
			else
			{
			dt=""+(date.getYear()-100)+"-0"+(date.getMonth()+1)+"-0"+(date.getDate());
			}
		}
		return dt;
	}
	public static void main(String args[])
	{
		ConnectionWaitingDAO dao=new ConnectionWaitingDAO();
		ConnectionWaitingVO[] voList=dao.selectGetConnectionWaitingList("h1");
		for(int i=0;i<voList.length;i++)
		{
			System.out.println(voList[i]);
		}
		dao.deleteConnectionWaiting("h4", "h1");
	}
}
