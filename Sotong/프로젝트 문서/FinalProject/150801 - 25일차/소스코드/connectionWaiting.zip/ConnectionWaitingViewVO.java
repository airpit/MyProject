package normal;

public class ConnectionWaitingViewVO {
	private String senderHomeCode;
	private String senderHomeName;
	private String senderHomeManagerName;
	private String receiverHomeCode;
	public ConnectionWaitingViewVO()
	{
	
	}
	public ConnectionWaitingViewVO(String senderHomeCode,
			String senderHomeName, String senderHomeManagerName,
			String receiverHomeCode) {
		this.senderHomeCode = senderHomeCode;
		this.senderHomeName = senderHomeName;
		this.senderHomeManagerName = senderHomeManagerName;
		this.receiverHomeCode = receiverHomeCode;
	}
	public String getSenderHomeCode() {
		return senderHomeCode;
	}
	public void setSenderHomeCode(String senderHomeCode) {
		this.senderHomeCode = senderHomeCode;
	}
	public String getSenderHomeName() {
		return senderHomeName;
	}
	public void setSenderHomeName(String senderHomeName) {
		this.senderHomeName = senderHomeName;
	}
	public String getSenderHomeManagerName() {
		return senderHomeManagerName;
	}
	public void setSenderHomeManagerName(String senderHomeManagerName) {
		this.senderHomeManagerName = senderHomeManagerName;
	}
	public String getReceiverHomeCode() {
		return receiverHomeCode;
	}
	public void setReceiverHomeCode(String receiverHomeCode) {
		this.receiverHomeCode = receiverHomeCode;
	}
	@Override
	public String toString() {
		return "ConnectionWaitingViewVO [senderHomeCode=" + senderHomeCode
				+ ", senderHomeName=" + senderHomeName
				+ ", senderHomeManagerName=" + senderHomeManagerName
				+ ", receiverHomeCode=" + receiverHomeCode + "]";
	}
	
	
}
