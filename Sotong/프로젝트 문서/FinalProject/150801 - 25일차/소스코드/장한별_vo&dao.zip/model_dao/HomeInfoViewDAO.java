package model_dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.crypto.Data;

import model_vo.FamilyMemberVO;
import model_vo.HomeInfoViewVO;
import model_vo.ImageVO;

public class HomeInfoViewDAO {
	private DBConnectionModule connModule;
	private Connection conn;
	
	public HomeInfoViewDAO() {
		connModule = DBConnectionModule.getInstance();
		conn = connModule.getConn();
	}
	
	public Date changeDate(String dateTime) { // String���� ������ data�� Date�� ����
	      int year = Integer.parseInt(dateTime.substring(0,2));
	      int mon = Integer.parseInt(dateTime.substring(3,5));
	      int date = Integer.parseInt(dateTime.substring(6,8));
	 
	      Date reDate = new Date(year,mon,date);
	      return reDate; 
	   }
	
	public HomeInfoViewVO[] selectHomeAllMember(String familyHomeCode)
	{
		HomeInfoViewVO vo = null;
		ArrayList<HomeInfoViewVO> voList = null;
		PreparedStatement pstmt = null;
		
		try{
			voList = new ArrayList<HomeInfoViewVO>();
			String sql = "select * from home_info_view where family_home_code=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, familyHomeCode);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){
				String memberCode = rs.getString("member_code");
				String memberPhone = rs.getString("member_phone");
				String memberEmail = rs.getString("member_email");
				String memberPhoto = rs.getString("member_photo");
				String memberNickName = rs.getString("member_nickname");
				String memberColor = rs.getString("member_color");
				Date memberBirth = changeDate(rs.getString("member_birth"));
				String memberRole = rs.getString("member_role");
				
				vo = new HomeInfoViewVO(familyHomeCode,memberCode,memberPhone,memberEmail,memberPhoto,memberNickName,memberColor,memberBirth,memberRole);
				voList.add(vo);
			}	
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		if(voList != null && voList.size()>=1)
		{
			return voList.toArray(new HomeInfoViewVO[voList.size()]);
		}
		else
		{
			return null;
		}
	}
	
	public HomeInfoViewVO selectHomeMember(String memberCode)
	{
		HomeInfoViewVO vo = null;
		PreparedStatement pstmt = null;
		
		try{
			String sql = "select * from home_info_view where member_code=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memberCode);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){				
				
				String familyHomeCode = rs.getString("family_home_code");
				String memberPhone = rs.getString("member_phone");
				String memberEmail = rs.getString("member_email");
				String memberPhoto = rs.getString("member_photo");
				String memberNickName = rs.getString("member_nickname");
				String memberColor = rs.getString("member_color");
				Date memberBirth = changeDate(rs.getString("member_birth"));
				String memberRole = rs.getString("member_role");
				
				vo = new HomeInfoViewVO(familyHomeCode,memberCode,memberPhone,memberEmail,memberPhoto,memberNickName,memberColor,memberBirth,memberRole);
				
			}	
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		
		return vo;
	}
	
	public String[][] getHomeMemberList(String familyHomeCode)
	{
		ArrayList<String[]> voList = null;
		PreparedStatement pstmt = null;
		
		try{
			voList = new ArrayList<String[]>();
			String sql = "select * from home_info_view where family_home_code=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, familyHomeCode);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){
				String memberCode = rs.getString("member_code");
				String memberPhoto = rs.getString("member_photo");
				String memberNickName = rs.getString("member_nickname");
				String memberColor = rs.getString("member_color");
				String memberBirth = rs.getString("member_birth");
				String memberRole = rs.getString("member_role");
				
				voList.add(new String[]{memberCode,memberPhoto,memberNickName,memberColor,memberBirth,memberRole});
				
			}	
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		
		return voList.toArray(new String[voList.size()][]);
	}
	
	public static void main(String[] args)
	{
		HomeInfoViewDAO dao = new HomeInfoViewDAO();
		HomeInfoViewVO[] voList = dao.selectHomeAllMember("h2");
		for(int i=0; i<voList.length;i++)
		{
			System.out.println("����Ʈ"+voList[i]);
		}
		
		System.out.println("���� �������� : " + dao.selectHomeMember("m7"));
		System.out.println("������ ����");
		String[][] memberList = dao.getHomeMemberList("h1");
		for(int i=0; i<memberList.length;i++)
		{
			for(int j=0; j<memberList[i].length;j++)
			System.out.println(memberList[i][j]);
		}
	}
		
}


