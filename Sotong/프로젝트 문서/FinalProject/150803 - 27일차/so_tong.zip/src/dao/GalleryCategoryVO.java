package dao;


public class GalleryCategoryVO {
	private String galleryCategoryCode;
	private String galleryCategory;
	
	public GalleryCategoryVO() {
		// TODO Auto-generated constructor stub
	}

	public GalleryCategoryVO(String galleryCategoryCode, String galleryCategory) {
		super();
		this.galleryCategoryCode = galleryCategoryCode;
		this.galleryCategory = galleryCategory;
	}

	public String getGalleryCategoryCode() {
		return galleryCategoryCode;
	}

	public void setGalleryCategoryCode(String galleryCategoryCode) {
		this.galleryCategoryCode = galleryCategoryCode;
	}

	public String getGalleryCategory() {
		return galleryCategory;
	}

	public void setGalleryCategory(String galleryCategory) {
		this.galleryCategory = galleryCategory;
	}


	public String toString() {
		return "GalleryCategoryVO [galleryCategoryCode=" + galleryCategoryCode
				+ ", galleryCategory=" + galleryCategory + "]";
	}
	
	

}
 