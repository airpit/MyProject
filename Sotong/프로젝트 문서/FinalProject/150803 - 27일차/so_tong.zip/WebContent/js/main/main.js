$(document).ready(function(){
    $("#loginImg").click(function(){
        $("#myLogin").modal();
    });
    
    $("#signupImg").click(function(){
        $("#mySignup").modal();
    });  
    
    $("#inBtn").click(function() {
    	if($("#userId").val()=="test" && $("#userPw").val()=="123")
    		{
    			alert("로그인 성공");
    			window.location.href = "JSP/home/myhome.jsp";
    		}
    	else
    		{
    			alert("로그인 실패");
    		}
    	
    });
    
    $("#okBtn").click(function() {
    	alert("회원가입에 성공하였습니다.");
    	$("#mySignup").modal("hide");
    });
    
    $("#cancelBtn").click(function(){
    	$("#mySignup").modal("hide");
    });
});